#include <stdarg.h>
#include"scanner.h"

typedef double(*FuncPtr)(double); //������typedef

struct ExprNode                  //type of syntax tree's node
{
	enum Token_Type OpCode;       //PLUS MINUS DIV POWER FUNC CONST_ID
	union
	{
		struct{ExprNode *Left,*Right;}CaseOperator;
		struct{ExprNode *Child;FuncPtr MathFuncPtr;}CaseFunc;
		double CaseConst;
		double * CaseParmPtr;
	}Content;
};

extern void Parser(char *SrcFilePtr);


