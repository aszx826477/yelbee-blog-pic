#include <stdio.h>
#include "parser.h"
#include <direct.h>

#define MAX_CHARS 200
char SrcFilePath[MAX_CHARS];

extern void Parser(char *SrcFilePtr);

int main(int argc, char *argv[])
{
	//����Դ�ļ�·��
	_getcwd(SrcFilePath, MAX_CHARS);//��ȡ��ǰĿ¼��·��
	strcat(SrcFilePath, "/test.txt");

	Parser(SrcFilePath);
	system("pause");
}