
clear
clc
close all
%   ---------------
%   A: Setting Parameters
%   ---------------
M = 4;                          %   QPSK signal constellation
no_of_data_points = 64;         %   have 64 data points
block_size = 8;                 %   size of each ofdm block
cp_len = ceil(0.1*block_size);  %   length of cyclic prefix
no_of_ifft_points = block_size; %   8 points for the FFT/IFFT
no_of_fft_points = block_size;
%   ---------------------------------------------
%   B:  %   +++++   TRANSMITTER    +++++
%   ---------------------------------------------
%   1.  Generate 1 x 64 vector of data points phase representations
data_source = randsrc(1, no_of_data_points, 0:M-1);
figure(1)
stem(data_source); grid on; xlabel('data points'); ylabel('transmitted data phase representation');
title('Transmitted Data');
%   2.  Perform QPSK modulation
qpsk_modulated_data = pskmod(data_source, M);
scatterplot(qpsk_modulated_data);title('qpsk modulated transmitted data');
%   3.  Do IFFT on each block
%   Make the serial stream a matrix where each column represents a pre-OFDM
%   block (w/o cyclic prefixing)
%   First: Find out the number of colums that will exist after reshaping
num_cols=length(qpsk_modulated_data)/block_size;
data_matrix = reshape(qpsk_modulated_data, block_size, num_cols);

%   Second: Create empty matix to put the IFFT'd data
cp_start = block_size-cp_len;
cp_end = block_size;

%   Third: Operate columnwise & do CP
for i=1:num_cols,
    ifft_data_matrix(:,i) = ifft((data_matrix(:,i)),no_of_ifft_points);
    %   Compute and append Cyclic Prefix
    for j=1:cp_len,
       actual_cp(j,i) = ifft_data_matrix(j+cp_start,i);
    end
    %   Append the CP to the existing block to create the actual OFDM block
    ifft_data(:,i) = vertcat(actual_cp(:,i),ifft_data_matrix(:,i));
end

%   Forth: Convert to serial stream for transmission
[rows_ifft_data cols_ifft_data]=size(ifft_data);
len_ofdm_data = rows_ifft_data*cols_ifft_data;

%   Actual OFDM signal to be transmitted
ofdm_signal = reshape(ifft_data, 1, len_ofdm_data);
figure(3)
plot(real(ofdm_signal)); xlabel('Time'); ylabel('Amplitude'); %Question: Why using real() not abs()?
title('OFDM Signal');grid on;


%   ------------------------------------------
%   E:  %   +++++   RECEIVER    +++++
%   ------------------------------------------

%   1.  Pass the ofdm signal through the channel without noise
recvd_signal = ofdm_signal;

%   4.  Convert Data back to "parallel" form to perform FFT
recvd_signal_matrix = reshape(recvd_signal, rows_ifft_data, cols_ifft_data);

%   5.  Remove CP
recvd_signal_no_cp = recvd_signal_matrix((cp_len+1):rows_ifft_data,:);

%   6.  Perform FFT
for i=1:num_cols
    recvd_data_matrix(:,i) = fft(recvd_signal_no_cp(:,i), no_of_fft_points);
end

%   7.  Convert to serial stream
len_recvd_data = no_of_data_points;
recvd_data_stream = reshape(recvd_data_matrix, 1, len_recvd_data);


%   8.  Demodulate the data(QPSK���)
recvd_data_deqpsk = pskdemod(recvd_data_stream, M);

%   9.  ����ͼ1��ͼ2�ĸ�ʽ�ֱ���ƽ����ź�
figure(4)
stem(recvd_data_deqpsk); grid on; xlabel('data points'); ylabel('received data phase representation');
title('Received Data');

scatterplot(recvd_data_stream);title('Received Data Constellation');

%   ------------------------------------------
%   Plus:  %   +++++   Other Plot Mission    +++++
%   ------------------------------------------
% Plot OFDM signal in the frequency domain
% OFDM�������ڣ�1s���ز�������4 --- y = sin(wx+��)
% ʱ���е����Ҳ�Ϊsin(2pit),sin(4pit) ,sin(6pit),sin(8pit) ����[0,1],t
% 1 2 3 4
x = -2 : pi/1000 : 8;
y1 = sinc(x-1);
y2 = sinc(x-2);
y3 = sinc(x-3);
y4 = sinc(x-4);
figure(6)
plot(x,y1,x,y2,x,y3,x,y4); grid on;
set(gca, 'xtick', -2:1:8);
axis([-2,8,-0.4,1.2]);
title('OFDM Sigal Frequency Map');xlabel('Frequency'); ylabel('|F(f)|');

% Plot sin()
t = 0: pi/1000 :1;
y1 = sin(2*pi*t);
y2 = sin(4*pi*t);
y3 = sin(6*pi*t);
y4 = sin(8*pi*t);
figure(7)
plot(t,y1,t,y2,t,y3,t,y4); grid on;
set(gca, 'xtick', 0:1/4:1);
set(gca, 'xticklabel', {'0', '1/4', '2/4', '3/4', '1'});
axis([0,1,-1,1]);
title('OFDM four sub-carrier wave');xlabel('Time');ylabel('Amplitude');

