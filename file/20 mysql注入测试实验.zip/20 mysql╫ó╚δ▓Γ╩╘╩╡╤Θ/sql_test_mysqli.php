<?php
	/*
	YellowBee
	2018-6-19
	This is a safe php using MySQLi_stmt against SQL injection.
	*/

	if(isset($_GET['op'])) {
		$mysqli = new mysqli('localhost', '****', '*****', 'test');
		if ($mysqli->connect_error) {  
    		die("Connection failed: " . $mysqli->connect_error);  
    	}

		$query = "select name,score from student where id = ?";
		$stmt = $mysqli -> prepare($query);
		$stmt -> bind_param("s", $id);
		$id = $_GET['id'];

		$stmt -> execute();
		$stmt->bind_result($name, $score);
		while($stmt -> fetch()) {
			echo 'name：'.$name.'<br/>';
			echo 'score：'.$score;
		}

		$stmt->close();  
		$mysqli->close(); 
	}

?>