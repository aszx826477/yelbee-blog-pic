<?php
	/*
	YellowBee
	2018-6-19
	This is a leaked php for SQL injection test.
	*/

	if(isset($_GET['op'])) {
		$sql = mysql_connect('localhost', '******', '*******');
		if($sql) {
			$op = $_GET['op'];
			switch($op) {
				case 1: //输入学号显示姓名和分数
					$id = $_GET['id'];
					mysql_select_db('test', $sql);
					$res = mysql_query("select * from student where id = '$id'");
					while($row = mysql_fetch_array($res)) {
						echo 'name：'.$row['name'].'<br/>';
						echo 'score：'.$row['score'];
					}
					break;
				case 2: //输入学号展示学生是否存在
					$id = $_GET['id'];
					mysql_select_db('test', $sql);
					$res = mysql_query("select * from student where id = '$id'");
					$row = mysql_fetch_array($res);
					if($row) {
						echo 'exist';
					} else {
						echo 'not exist';
					}
					break;
				case 3: //将查询结果是否为空展示在两段随机内容之间
					$id = $_GET['id'];
					mysql_select_db('test', $sql);
					$res = mysql_query("select * from student where id = '$id'");
					$row = mysql_fetch_array($res);
					if($row) {
						echo rand().'exist'.rand();
					} else {
						echo rand().'not exist'.rand();
					}
					break;
				case 4: //输入学号，查询成绩是否大于60，结果展示在两段随机内容之间
					$id = $_GET['id'];
					mysql_select_db('test', $sql);
					$res = mysql_query("select * from student where id = '$id' and score > 60");
					$row = mysql_fetch_array($res);
					if($row) {
						echo rand().'(score > 60)'.rand();
					} else {
						echo rand().'(score <= 60)'.rand();
					}
					break;
				case 5: //输入学号展示学生是否存在，但输出固定内容
					$id = $_GET['id'];
					mysql_select_db('test', $sql);
					$res = mysql_query("select * from student where id = '$id'");
					$row = mysql_fetch_array($res);
					if($row) {
						echo 'query ok';
					} else {
						echo 'query ok';
					}
					break;
				case 6: //输入学号和分数，更新对应学生的分数
					$id = $_GET['id'];
					$score = $_GET['score'];
					mysql_select_db('test', $sql);
					if(mysql_query("update student set score ='$score' where id = '$id'")) {
						echo 'update ok';
					} else {
						echo 'updata fail';
					}
					break;
				default:
					break;
			}
		} else {
			die("connect error: " . mysql_connect_error());
		}
		
		mysql_close($sql);
	}

?>