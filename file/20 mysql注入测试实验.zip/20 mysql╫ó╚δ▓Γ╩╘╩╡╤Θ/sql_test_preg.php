<?php
	/*
	YellowBee
	2018-6-19
	This is a safe php using preg_match() against SQL injection.
	*/

	if(isset($_GET['op'])) {
		$id = $_GET['id'];
		mysql_connect('localhost', '****', '****')
		mysql_select_db('test', $sql);

		$preg = '/select|insert|update|delete|\'|\/\*|\*|\.\.\/|\.\/|union|into|load_file|outfile|or|and|-|<|>|&|%|limit|where|oR|aNd/';
		if(preg_match($preg, $id)) {
			echo 'invalid input';
			die();
		}

		$res = mysql_query("select * from student where id = '$id'");
		while($row = mysql_fetch_array($res)) {
			echo 'name：'.$row['name'].'<br/>';
			echo 'score：'.$row['score'];
		}
	}

?>