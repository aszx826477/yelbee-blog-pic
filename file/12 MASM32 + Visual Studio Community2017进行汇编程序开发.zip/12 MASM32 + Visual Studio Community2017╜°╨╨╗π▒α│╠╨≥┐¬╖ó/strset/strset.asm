.386
.model flat, stdcall

include kernel32.inc
includelib kernel32.lib

include msvcrt.inc
includelib msvcrt.lib

.data
szText	db	"Reverse Engineering", 0 ;�ַ���s
chr		db	'j' ;���ַ���s�е������ַ������ó�j

.code

main PROC
	LEA EDI, szText
	LEA ESI, chr
	MOV ECX,0FFFFFFFFH
	;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
	;strset�߼�
	MOV EBX, [ESI]
CICLE:
	MOV AX, [EDI]
	CMP AL, 0
	JZ STOP
	MOV [EDI], BL
	INC EDI
	JMP CICLE
STOP:

	;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
	INVOKE crt_printf, addr szText

	INVOKE crt_getchar
	INVOKE ExitProcess, 0
main ENDP

END main