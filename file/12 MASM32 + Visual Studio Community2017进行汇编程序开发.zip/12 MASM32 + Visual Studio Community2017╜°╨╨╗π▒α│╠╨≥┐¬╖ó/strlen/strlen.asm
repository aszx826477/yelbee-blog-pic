.386
.model flat, stdcall

include kernel32.inc
includelib kernel32.lib

include msvcrt.inc
includelib msvcrt.lib

.data
szText	db	"Reverse Engineering", 0   ;Reverse Engineering Length = 19
format	db	"length = %d", 0AH, 0

.code

main PROC
	LEA EDI, szText
	MOV ECX,0FFFFFFFFH
	;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
	;strlen�߼�
CASE1:
	MOV EBX, [EDI]
	INC ECX
	INC EDI
	CMP BL, 0
	JZ CASE2
	JNZ CASE1
CASE2:
	;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
	INVOKE crt_printf, addr format, ECX
	INVOKE crt_getchar
	INVOKE ExitProcess, 0
main ENDP

END main