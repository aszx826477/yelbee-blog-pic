.386
.model flat, stdcall
option casemap: none

include windows.inc
include kernel32.inc
include user32.inc

includelib kernel32.lib
includelib user32.lib

include msvcrt.inc
includelib msvcrt.lib

.data
szCaption   db  "Reverse Engineering", 0
szText      db  "Hello World!", 0
format		db	"%d",0AH,0

.code

main PROC

MOV EAX,3
XOR EBX, EAX
XOR EAX, EBX
XOR EBX, EAX
INC EAX
NEG EBX
ADD EBX, 0A6098326H
CMP EAX, ESP
MOV EAX, 59F67CD5H
XOR EAX, 0FFFFFFFFH
SUB EBX, EAX
RCL EAX, CL
PUSH 0F9CBE47AH
ADD DWORD PTR [ESP], 6341B86H
SBB EAX, EBP
SUB DWORD PTR [ESP], EBX
PUSHFD
PUSHAD
POP EAX
ADD ESP, 20H
TEST EBX, EAX
POP EAX
INVOKE crt_printf, addr format, EAX

    INVOKE MessageBox, NULL, addr szText, addr szCaption, MB_OK
    INVOKE ExitProcess, 0
main ENDP

END main