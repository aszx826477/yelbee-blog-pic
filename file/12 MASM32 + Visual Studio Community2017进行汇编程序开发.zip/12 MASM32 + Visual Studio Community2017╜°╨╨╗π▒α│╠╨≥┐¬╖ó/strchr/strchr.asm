.386
.model flat, stdcall

include kernel32.inc
includelib kernel32.lib

include msvcrt.inc
includelib msvcrt.lib

.data
szText	db	"Reverse Engineering", 0 ;Ŀ���ַ���s
chr		db	'i' ;��Ҫ��s�в���λ�õ��ַ�c
format	db	"%d", 0AH, 0

.code

main PROC
	LEA EDI, szText
	LEA ESI, chr
	MOV ECX,0FFFFFFFFH
	;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
	;strchr�߼�
CASE0:
	INC ECX
	MOV EAX, [EDI+ECX]
	CMP AL, [ESI]
	JZ CASE2
	CMP AL, 0
	JNZ CASE0
	MOV EDX, 0
	JMP STOP
CASE2:
	MOV EDX, ECX
STOP:
	;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
	INVOKE crt_printf, addr format, EDX
	INVOKE crt_getchar
	INVOKE ExitProcess, 0
main ENDP

END main